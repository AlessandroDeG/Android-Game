package com.example.game;

import android.graphics.Rect;
import android.util.Log;

public class test {
    /*
    if(boss == true){
        Rect bossRect = new Rect(Boss.posX, Boss.posY, Boss.posX+Boss.SIZE, Boss.posY+Boss.SIZE);

        if(PlayFragment.skins) {
            Log.d("BOSS", "BATTLE");
            //if(Boss.animation.getCurrentSkin()!=null) {
            canvas.drawBitmap(Boss.animation.getCurrentSkin(), null, bossRect, null);
            //}
        }
        else{

            canvas.drawRect(bossRect,Boss.color);
        }
    }
    */
}
